const DRAIN_URL = "http://178.105.135.26/drain/post";

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'CAPTURE') {
    const { info } = msg;
    const contenido = `CAPTURA de ${info.site}

Elemento: <${info.tag}>
Texto: ${info.text}
Tamaño: ${info.size.w}×${info.size.h}px

CSS:
  color: ${info.css.color}
  background: ${info.css.background}
  font: ${info.css.font} ${info.css.fontSize} w${info.css.fontWeight}
  border-radius: ${info.css.borderRadius}
  padding: ${info.css.padding}
  box-shadow: ${info.css.boxShadow}
  border: ${info.css.border}

HTML: ${info.html}`;

    fetch(DRAIN_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        agent: 'pedro',
        target: 'pablo',
        tipo: 'inspiracion',
        contenido,
        url: info.url,
        prioridad: 7
      })
    })
    .then(r => r.json())
    .then(d => sendResponse({ ok: d.ok, id: d.id }))
    .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});

// Context menu "Capturar con VForge"
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'vforge-capture',
    title: '⚡ Capturar con VForge',
    contexts: ['all']
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'vforge-capture') {
    chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_CAPTURE' });
  }
});

// Guardar en storage local para historial en popup
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'CAPTURE') {
    chrome.storage.local.get(['captures'], r => {
      const caps = r.captures || [];
      caps.push({
        site: new URL(msg.info.url).hostname,
        tag: msg.info.tag,
        text: msg.info.text.slice(0, 60),
        ts: Date.now()
      });
      chrome.storage.local.set({ captures: caps.slice(-20) });
    });
  }
});
