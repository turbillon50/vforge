const DRAIN_URL = "http://178.105.135.26/drain/post";

// Abrir side panel al hacer clic en el ícono
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

// Habilitar side panel en todas las páginas
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setOptions({ enabled: true });

  chrome.contextMenus.create({
    id: 'vforge-capture',
    title: '⚡ Capturar con VForge',
    contexts: ['all']
  });

  chrome.contextMenus.create({
    id: 'vforge-grok',
    title: '🤖 Clonar con Grok',
    contexts: ['all']
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'vforge-capture') {
    chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_CAPTURE' });
  }
  if (info.menuItemId === 'vforge-grok') {
    chrome.sidePanel.open({ tabId: tab.id });
  }
});

// Guardar capturas en storage + Brain
function saveLocal(info) {
  chrome.storage.local.get(['captures'], r => {
    const caps = r.captures || [];
    caps.push({
      site: new URL(info.url).hostname,
      tag: info.tag,
      text: info.text.slice(0, 60),
      ts: Date.now()
    });
    chrome.storage.local.set({ captures: caps.slice(-20) });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== 'CAPTURE') return;
  const { info } = msg;

  const contenido = `CAPTURA de ${info.site}
Elemento: <${info.tag}>
Texto: ${info.text}
Tamaño: ${info.size.w}×${info.size.h}px
CSS: color:${info.css.color} bg:${info.css.background} font:${info.css.font} ${info.css.fontSize} br:${info.css.borderRadius}
HTML: ${info.html}`;

  fetch(DRAIN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      agent: 'chrome-plugin',
      target: 'pablo',
      tipo: 'inspiracion',
      contenido,
      url: info.url,
      prioridad: 7
    })
  })
  .then(r => r.json())
  .then(d => {
    saveLocal(info);
    // Notificar al side panel
    chrome.tabs.sendMessage(sender.tab.id, {
      type: 'CAPTURED',
      site: new URL(info.url).hostname
    }).catch(() => {});
    sendResponse({ ok: d.ok });
  })
  .catch(e => sendResponse({ ok: false, error: e.message }));

  return true;
});
