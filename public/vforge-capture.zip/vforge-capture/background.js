const DRAIN_URL = "https://metamcp.vforge.site/grok/mcp";
const DRAIN_FALLBACK = "http://178.105.135.26/drain/post";

// Guarda en storage local el historial
function saveLocal(info) {
  chrome.storage.local.get(['captures'], r => {
    const caps = r.captures || [];
    caps.push({ site: new URL(info.url).hostname, tag: info.tag, text: info.text.slice(0, 60), ts: Date.now() });
    chrome.storage.local.set({ captures: caps.slice(-20) });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== 'CAPTURE') return;
  const { info } = msg;

  const contenido = `CAPTURA de ${info.site}

Elemento: <${info.tag}>
Texto: ${info.text}
Tamaño: ${info.size.w}×${info.size.h}px

CSS:
  color: ${info.css.color}
  background: ${info.css.background}
  font: ${info.css.font} ${info.css.fontSize} w${info.css.fontWeight}
  border-radius: ${info.css.borderRadius}
  padding: ${info.css.padding}
  box-shadow: ${info.css.boxShadow}
  border: ${info.css.border}

HTML: ${info.html}`;

  // Intentar via MCP brain primero, fallback al drain directo
  const mcpPayload = JSON.stringify({
    jsonrpc: "2.0",
    method: "tools/call",
    params: {
      name: "drain_post",
      arguments: {
        agent: "chrome-plugin",
        target: "pablo",
        tipo: "inspiracion",
        contenido,
        url: info.url,
        prioridad: 7
      }
    },
    id: Date.now()
  });

  fetch(DRAIN_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json, text/event-stream'
    },
    body: mcpPayload
  })
  .then(r => r.text())
  .then(text => {
    // parsear SSE o JSON directo
    const line = text.split('\n').find(l => l.startsWith('data:'));
    const data = line ? JSON.parse(line.slice(5)) : JSON.parse(text);
    const ok = !data.error;
    saveLocal(info);
    sendResponse({ ok });
  })
  .catch(() => {
    // fallback drain HTTP directo
    fetch(DRAIN_FALLBACK, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ agent: 'chrome-plugin', target: 'pablo', tipo: 'inspiracion', contenido, url: info.url, prioridad: 7 })
    })
    .then(r => r.json())
    .then(d => { saveLocal(info); sendResponse({ ok: d.ok }); })
    .catch(e => sendResponse({ ok: false, error: e.message }));
  });

  return true;
});

// Context menu
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'vforge-capture',
    title: '⚡ Capturar con VForge',
    contexts: ['all']
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'vforge-capture') {
    chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_CAPTURE' });
  }
});
