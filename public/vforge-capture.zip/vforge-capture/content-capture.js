// VForge Capture — content script universal
(function() {
  if (window.__vforge_capture_loaded) return;
  window.__vforge_capture_loaded = true;

  let highlightEl = null;
  let overlay = null;
  let captureMode = false;

  // Overlay flotante siempre visible (mini badge)
  function createBadge() {
    const badge = document.createElement('div');
    badge.id = '__vf_badge';
    badge.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 48 48" fill="none">
        <path d="M8 10 L24 38 L40 10 L34 10 L24 28 L14 10 Z" fill="white"/>
      </svg>
    `;
    badge.style.cssText = `
      position:fixed; bottom:20px; right:20px; width:40px; height:40px;
      background:#7c3aed; border-radius:50%; z-index:2147483647;
      display:flex; align-items:center; justify-content:center;
      cursor:pointer; box-shadow:0 2px 12px rgba(124,58,237,0.5);
      transition:transform 0.2s, box-shadow 0.2s;
      border: 1.5px solid rgba(255,255,255,0.2);
    `;
    badge.onmouseenter = () => { badge.style.transform = 'scale(1.1)'; badge.style.boxShadow = '0 4px 20px rgba(124,58,237,0.7)'; };
    badge.onmouseleave = () => { badge.style.transform = 'scale(1)'; badge.style.boxShadow = '0 2px 12px rgba(124,58,237,0.5)'; };
    badge.onclick = toggleCaptureMode;
    document.body.appendChild(badge);
    return badge;
  }

  // Highlight al hover en modo captura
  function createHighlight() {
    const el = document.createElement('div');
    el.id = '__vf_highlight';
    el.style.cssText = `
      position:fixed; pointer-events:none; z-index:2147483646;
      border:2px solid #22d3ee; background:rgba(34,211,238,0.06);
      border-radius:4px; transition:all 0.1s; display:none;
      box-shadow:0 0 0 1px rgba(34,211,238,0.3);
    `;
    document.body.appendChild(el);
    return el;
  }

  // Toast de confirmación
  function showToast(msg, ok = true) {
    const t = document.createElement('div');
    t.style.cssText = `
      position:fixed; bottom:72px; right:20px; z-index:2147483647;
      background:${ok ? '#7c3aed' : '#ef4444'}; color:white;
      padding:10px 16px; border-radius:8px; font-family:system-ui;
      font-size:13px; font-weight:500; box-shadow:0 4px 16px rgba(0,0,0,0.3);
      animation: vf-slide-in 0.2s ease; max-width:260px;
    `;
    t.textContent = msg;
    if (!document.getElementById('__vf_toast_style')) {
      const s = document.createElement('style');
      s.id = '__vf_toast_style';
      s.textContent = `@keyframes vf-slide-in { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }`;
      document.head.appendChild(s);
    }
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2800);
  }

  function toggleCaptureMode() {
    captureMode = !captureMode;
    const badge = document.getElementById('__vf_badge');
    if (captureMode) {
      badge.style.background = '#22d3ee';
      badge.style.boxShadow = '0 2px 20px rgba(34,211,238,0.6)';
      showToast('Haz clic en lo que te gusta ✦', true);
      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('click', onCapture, true);
      document.body.style.cursor = 'crosshair';
    } else {
      badge.style.background = '#7c3aed';
      badge.style.boxShadow = '0 2px 12px rgba(124,58,237,0.5)';
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('click', onCapture, true);
      document.body.style.cursor = '';
      if (overlay) overlay.style.display = 'none';
    }
  }

  function onMouseMove(e) {
    if (!overlay) overlay = createHighlight();
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el || el.id === '__vf_badge' || el.id === '__vf_highlight') return;
    highlightEl = el;
    const r = el.getBoundingClientRect();
    overlay.style.display = 'block';
    overlay.style.left   = r.left + 'px';
    overlay.style.top    = r.top + 'px';
    overlay.style.width  = r.width + 'px';
    overlay.style.height = r.height + 'px';
  }

  function onCapture(e) {
    if (!captureMode) return;
    const el = e.target;
    if (el.id === '__vf_badge' || el.id === '__vf_highlight') return;
    e.preventDefault(); e.stopPropagation();

    // Extraer info del elemento
    const computed = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    const info = {
      tag: el.tagName.toLowerCase(),
      text: el.textContent?.trim().slice(0, 120) || '',
      html: el.outerHTML?.slice(0, 300) || '',
      url: location.href,
      site: location.hostname,
      css: {
        color: computed.color,
        background: computed.backgroundColor,
        font: computed.fontFamily,
        fontSize: computed.fontSize,
        fontWeight: computed.fontWeight,
        borderRadius: computed.borderRadius,
        padding: computed.padding,
        boxShadow: computed.boxShadow,
        border: computed.border,
      },
      size: { w: Math.round(rect.width), h: Math.round(rect.height) }
    };

    // Mandar al Brain
    chrome.runtime.sendMessage({ type: 'CAPTURE', info }, r => {
      if (r?.ok) {
        showToast('✓ Capturado y guardado en tu VForge');
      } else {
        showToast('Error al guardar — revisa conexión', false);
      }
    });

    // Salir del modo captura
    toggleCaptureMode();
  }

  // Iniciar
  if (document.body) {
    createBadge();
  } else {
    document.addEventListener('DOMContentLoaded', createBadge);
  }

  // Escuchar toggle desde popup
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'TOGGLE_CAPTURE') toggleCaptureMode();
  });
})();
