// Drain Inspector - drena inspiración de páginas de referencia
(function() {
  if (document.getElementById('vf-drain-panel')) return;

  const panel = document.createElement('div');
  panel.id = 'vf-drain-panel';
  panel.innerHTML = `
    <div id="vf-drain-header">
      <span>🎨 Pedro — Drain</span>
      <button id="vf-drain-close">✕</button>
    </div>
    <div id="vf-drain-body">
      <div id="vf-drain-status">Listo para drenar</div>
      <div id="vf-drain-actions">
        <button class="vfd-btn" id="vfd-colors">🎨 Colores</button>
        <button class="vfd-btn" id="vfd-fonts">🔤 Tipografías</button>
        <button class="vfd-btn" id="vfd-components">📦 Componentes</button>
        <button class="vfd-btn" id="vfd-send">📤 Enviar a Pablo</button>
      </div>
      <div id="vf-drain-preview"></div>
      <textarea id="vf-drain-note" placeholder="Nota manual sobre este elemento..." rows="3"></textarea>
      <button class="vfd-btn" id="vfd-send-note" style="width:100%;margin-top:4px">📤 Enviar nota</button>
    </div>
  `;

  const style = document.createElement('style');
  style.textContent = `
    #vf-drain-panel {
      position: fixed; bottom: 20px; left: 20px; width: 300px;
      background: #03020a; border: 1px solid #22d3ee;
      border-radius: 12px; z-index: 999999; font-family: monospace;
      box-shadow: 0 0 30px rgba(34,211,238,0.3); color: rgba(255,255,255,0.9);
      font-size: 12px;
    }
    #vf-drain-header {
      display: flex; justify-content: space-between; align-items: center;
      padding: 10px 14px; background: #22d3ee; border-radius: 11px 11px 0 0;
      font-weight: bold; font-size: 13px; color: #03020a;
    }
    #vf-drain-header button { background:none; border:none; cursor:pointer; font-size:14px; }
    #vf-drain-body { padding: 12px; }
    #vf-drain-status { color: #22d3ee; margin-bottom: 8px; font-size: 11px; }
    #vf-drain-actions { display:flex; gap:4px; flex-wrap:wrap; margin-bottom:8px; }
    .vfd-btn {
      background: rgba(34,211,238,0.1); border: 1px solid #22d3ee;
      color: white; padding: 5px 8px; border-radius: 6px;
      cursor: pointer; font-size: 11px; font-family: monospace;
    }
    .vfd-btn:hover { background: rgba(34,211,238,0.3); }
    #vf-drain-preview {
      background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08);
      border-radius: 6px; padding: 8px; margin-bottom: 8px;
      max-height: 200px; overflow-y: auto; font-size: 10px; line-height: 1.6;
    }
    #vf-drain-note {
      width: 100%; background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.1); color: white;
      border-radius: 6px; padding: 6px; font-family: monospace; font-size: 11px;
      box-sizing: border-box; resize: vertical;
    }
    .drain-swatch { display:inline-block; width:14px; height:14px; border-radius:3px; margin-right:4px; vertical-align:middle; border:1px solid rgba(255,255,255,0.2); }
  `;
  document.head.appendChild(style);
  document.body.appendChild(panel);

  function setStatus(msg) { document.getElementById('vf-drain-status').textContent = msg; }
  function setPreview(html) { document.getElementById('vf-drain-preview').innerHTML = html; }

  // Extraer colores únicos de la página
  function extractColors() {
    const colors = new Set();
    document.querySelectorAll('*').forEach(el => {
      const s = getComputedStyle(el);
      ['color','backgroundColor','borderColor','fill','stroke'].forEach(p => {
        const v = s[p];
        if (v && v !== 'rgba(0, 0, 0, 0)' && v !== 'transparent' && v.includes('rgb')) colors.add(v);
      });
    });
    return [...colors].slice(0, 30);
  }

  // Extraer tipografías
  function extractFonts() {
    const fonts = new Set();
    document.querySelectorAll('*').forEach(el => {
      const f = getComputedStyle(el).fontFamily;
      if (f) fonts.add(f.split(',')[0].trim().replace(/['"]/g,''));
    });
    return [...fonts].filter(f => f && f !== 'inherit');
  }

  // Componentes destacados (hero, nav, cards, CTAs)
  function extractComponents() {
    const comps = [];
    const selectors = [
      { sel: 'nav, header', name: 'Navegación' },
      { sel: 'h1', name: 'Hero H1' },
      { sel: '[class*="hero"], [class*="Hero"]', name: 'Hero section' },
      { sel: 'button, [class*="btn"], [class*="cta"]', name: 'Botones/CTAs' },
      { sel: '[class*="card"], [class*="Card"]', name: 'Cards' },
      { sel: 'footer', name: 'Footer' },
    ];
    selectors.forEach(({ sel, name }) => {
      const els = document.querySelectorAll(sel);
      if (els.length) comps.push({ name, count: els.length, sample: els[0].className.toString().slice(0,60) });
    });
    return comps;
  }

  function sendToBrain(contenido, tipo = 'inspiracion', prioridad = 7) {
    chrome.runtime.sendMessage({
      type: 'DRAIN_POST',
      agent: 'pedro',
      target: 'pablo',
      tipo,
      contenido,
      url: location.href,
      prioridad
    }, r => {
      setStatus(r?.ok ? '✓ Enviado a Pablo' : '✗ Error al enviar');
    });
  }

  // Botones
  document.getElementById('vfd-colors').onclick = () => {
    const colors = extractColors();
    const html = colors.map(c => `<span class="drain-swatch" style="background:${c}"></span>${c}`).join('<br>');
    setPreview(html);
    setStatus(`${colors.length} colores encontrados`);
  };

  document.getElementById('vfd-fonts').onclick = () => {
    const fonts = extractFonts();
    setPreview(fonts.map(f => `🔤 ${f}`).join('<br>'));
    setStatus(`${fonts.length} tipografías`);
  };

  document.getElementById('vfd-components').onclick = () => {
    const comps = extractComponents();
    setPreview(comps.map(c => `📦 <b>${c.name}</b> (${c.count})<br><span style="opacity:0.5">${c.sample}</span>`).join('<br><br>'));
    setStatus(`${comps.length} tipos de componentes`);
  };

  document.getElementById('vfd-send').onclick = () => {
    const colors = extractColors().slice(0, 10);
    const fonts  = extractFonts().slice(0, 5);
    const comps  = extractComponents();
    const contenido = `DRAIN de ${location.hostname}:

COLORES:
${colors.join('\n')}

TIPOGRAFÍAS:
${fonts.join('\n')}

COMPONENTES:
${comps.map(c => `- ${c.name}: ${c.count} instancias`).join('\n')}

URL: ${location.href}`;
    sendToBrain(contenido, 'inspiracion', 8);
    setStatus('📤 Enviando todo a Pablo...');
  };

  document.getElementById('vfd-send-note').onclick = () => {
    const note = document.getElementById('vf-drain-note').value.trim();
    if (!note) return;
    sendToBrain(note, 'nota', 6);
    document.getElementById('vf-drain-note').value = '';
  };

  document.getElementById('vf-drain-close').onclick = () => panel.remove();
  setStatus(`✓ Activo en ${location.hostname}`);
})();
