const RELAY = "https://metamcp.vforge.site/grok/chat";
const msgs = document.getElementById("messages");
const input = document.getElementById("input");
const send = document.getElementById("send");
const ctxBar = document.getElementById("ctx-bar");

let currentUrl = "";
let currentTitle = "";

// Obtener contexto de la pestaña activa
function updateContext() {
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    if (tabs[0]) {
      currentUrl = tabs[0].url || "";
      currentTitle = tabs[0].title || "";
      ctxBar.textContent = currentTitle ? `📄 ${currentTitle}` : currentUrl;
    }
  });
}
updateContext();
chrome.tabs.onActivated.addListener(updateContext);
chrome.tabs.onUpdated.addListener((id, info) => { if (info.status === 'complete') updateContext(); });

function addMsg(text, type) {
  const d = document.createElement("div");
  d.className = `msg ${type}`;
  d.textContent = text;
  msgs.appendChild(d);
  msgs.scrollTop = msgs.scrollHeight;
  return d;
}

async function sendMsg() {
  const text = input.value.trim();
  if (!text) return;

  input.value = "";
  input.style.height = "auto";
  send.disabled = true;

  addMsg(text, "user");
  const thinking = addMsg("⚡ procesando...", "thinking");

  try {
    const res = await fetch(RELAY, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: text,
        context: `URL: ${currentUrl}\nTITLE: ${currentTitle}`,
        session: "sidepanel"
      })
    });
    const data = await res.json();
    thinking.remove();

    if (data.ok) {
      addMsg(data.response, "vulcano");
    } else {
      addMsg("Error: " + (data.error || "sin respuesta"), "system");
    }
  } catch (e) {
    thinking.remove();
    addMsg("Error de conexión: " + e.message, "system");
  }

  send.disabled = false;
  input.focus();
}

send.addEventListener("click", sendMsg);
input.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); e.stopPropagation(); sendMsg(); }
});
input.addEventListener("input", () => {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 80) + "px";
});