// VForge QA Inspector - content script para vforge.site
(function() {
  if (document.getElementById('vf-qa-panel')) return;

  // Panel flotante
  const panel = document.createElement('div');
  panel.id = 'vf-qa-panel';
  panel.innerHTML = `
    <div id="vf-qa-header">
      <span>⚡ VForge QA</span>
      <div>
        <button id="vf-qa-minimize">_</button>
        <button id="vf-qa-close">✕</button>
      </div>
    </div>
    <div id="vf-qa-body">
      <div id="vf-qa-status">Monitoreando...</div>
      <div id="vf-qa-errors"></div>
      <div id="vf-qa-actions">
        <button class="vf-btn" id="vf-scan">🔍 Escanear página</button>
        <button class="vf-btn" id="vf-screenshot">📸 Capturar</button>
        <button class="vf-btn" id="vf-report">📤 Reportar todo</button>
      </div>
      <div id="vf-qa-log"></div>
    </div>
  `;

  const style = document.createElement('style');
  style.textContent = `
    #vf-qa-panel {
      position: fixed; bottom: 20px; right: 20px; width: 320px;
      background: #0a0814; border: 1px solid #7c3aed;
      border-radius: 12px; z-index: 999999; font-family: monospace;
      box-shadow: 0 0 30px rgba(124,58,237,0.4);
      color: rgba(255,255,255,0.9); font-size: 12px;
    }
    #vf-qa-header {
      display: flex; justify-content: space-between; align-items: center;
      padding: 10px 14px; background: #7c3aed; border-radius: 11px 11px 0 0;
      font-weight: bold; font-size: 13px; cursor: move;
    }
    #vf-qa-header button {
      background: none; border: none; color: white;
      cursor: pointer; font-size: 14px; padding: 0 4px;
    }
    #vf-qa-body { padding: 12px; max-height: 400px; overflow-y: auto; }
    #vf-qa-status { color: #22d3ee; margin-bottom: 8px; font-size: 11px; }
    #vf-qa-errors { margin-bottom: 8px; }
    .vf-error-item {
      background: rgba(239,68,68,0.1); border-left: 3px solid #ef4444;
      padding: 6px 8px; margin-bottom: 4px; border-radius: 4px; font-size: 11px;
    }
    .vf-warn-item {
      background: rgba(251,191,36,0.1); border-left: 3px solid #fbbf24;
      padding: 6px 8px; margin-bottom: 4px; border-radius: 4px; font-size: 11px;
    }
    .vf-ok-item {
      background: rgba(34,211,238,0.08); border-left: 3px solid #22d3ee;
      padding: 6px 8px; margin-bottom: 4px; border-radius: 4px; font-size: 11px;
    }
    #vf-qa-actions { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 8px; }
    .vf-btn {
      background: rgba(124,58,237,0.2); border: 1px solid #7c3aed;
      color: white; padding: 5px 8px; border-radius: 6px;
      cursor: pointer; font-size: 11px; font-family: monospace;
    }
    .vf-btn:hover { background: rgba(124,58,237,0.5); }
    #vf-qa-log { font-size: 10px; color: rgba(255,255,255,0.5); }
    .vf-log-line { margin-bottom: 2px; }
  `;
  document.head.appendChild(style);
  document.body.appendChild(panel);

  // Estado
  const errors = [];
  let minimized = false;

  function log(msg) {
    const logEl = document.getElementById('vf-qa-log');
    const line = document.createElement('div');
    line.className = 'vf-log-line';
    line.textContent = `[${new Date().toLocaleTimeString()}] ${msg}`;
    logEl.prepend(line);
    if (logEl.children.length > 20) logEl.lastChild.remove();
  }

  function addError(type, msg) {
    errors.push({ type, msg, url: location.href, ts: Date.now() });
    const el = document.getElementById('vf-qa-errors');
    const item = document.createElement('div');
    item.className = type === 'error' ? 'vf-error-item' : type === 'warn' ? 'vf-warn-item' : 'vf-ok-item';
    item.textContent = msg.length > 80 ? msg.slice(0, 80) + '...' : msg;
    el.prepend(item);
    if (el.children.length > 15) el.lastChild.remove();
  }

  // Interceptar consola
  const _error = console.error.bind(console);
  const _warn  = console.warn.bind(console);
  console.error = (...args) => { addError('error', args.join(' ')); _error(...args); };
  console.warn  = (...args) => { addError('warn',  args.join(' ')); _warn(...args);  };

  // Interceptar errores globales
  window.addEventListener('error', e => addError('error', `JS: ${e.message} @ ${e.filename}:${e.lineno}`));
  window.addEventListener('unhandledrejection', e => addError('error', `Promise: ${e.reason}`));

  // Escaneo visual
  function scanPage() {
    const issues = [];
    document.getElementById('vf-qa-status').textContent = 'Escaneando...';

    // Overflow horizontal
    document.querySelectorAll('*').forEach(el => {
      if (el.scrollWidth > el.clientWidth + 5 && el !== document.body) {
        issues.push({ type: 'warn', msg: `Overflow: <${el.tagName.toLowerCase()}> ${el.className.toString().slice(0,30)}` });
      }
    });

    // Botones sin texto o sin handler visible
    document.querySelectorAll('button, a[href="#"], a:not([href])').forEach(el => {
      if (!el.textContent.trim() && !el.querySelector('svg, img')) {
        issues.push({ type: 'error', msg: `Botón vacío: ${el.outerHTML.slice(0,60)}` });
      }
    });

    // Imágenes rotas
    document.querySelectorAll('img').forEach(img => {
      if (!img.complete || img.naturalWidth === 0) {
        issues.push({ type: 'error', msg: `Imagen rota: ${img.src.slice(0,60)}` });
      }
    });

    // Variables CSS VForge faltantes
    const computed = getComputedStyle(document.documentElement);
    ['--vf-fg','--vf-bg','--vf-border'].forEach(v => {
      if (!computed.getPropertyValue(v).trim()) {
        issues.push({ type: 'warn', msg: `Variable CSS faltante: ${v}` });
      }
    });

    if (issues.length === 0) {
      addError('ok', `✓ Sin issues visuales detectados (${document.querySelectorAll('*').length} elementos)`);
    } else {
      issues.forEach(i => addError(i.type, i.msg));
    }

    document.getElementById('vf-qa-status').textContent = `Escaneado: ${issues.length} issues`;
    log(`Scan completo: ${issues.length} issues`);
    return issues;
  }

  // Reportar al Brain
  function reportAll() {
    const allIssues = [...errors];
    if (allIssues.length === 0) {
      log('Nada que reportar');
      return;
    }
    const contenido = allIssues.map(e => `[${e.type.toUpperCase()}] ${e.msg}`).join('\n');
    chrome.runtime.sendMessage({
      type: 'DRAIN_POST',
      agent: 'pablo',
      target: 'vulcano',
      tipo: 'bug',
      contenido: `VForge QA Report (${allIssues.length} issues):\n${contenido}`,
      url: location.href,
      prioridad: allIssues.some(e => e.type === 'error') ? 8 : 5
    }, r => {
      log(r?.ok ? `✓ Reportado al Brain (id: ${r?.result?.result?.content?.[0]?.text?.match(/"id":"(\d+)"/)?.[1] || '?'})` : '✗ Error al reportar');
    });
  }

  // Eventos
  document.getElementById('vf-scan').onclick    = scanPage;
  document.getElementById('vf-report').onclick  = reportAll;
  document.getElementById('vf-qa-close').onclick = () => panel.remove();
  document.getElementById('vf-qa-minimize').onclick = () => {
    minimized = !minimized;
    document.getElementById('vf-qa-body').style.display = minimized ? 'none' : 'block';
  };

  // Drag
  const header = document.getElementById('vf-qa-header');
  let ox=0, oy=0, sx=0, sy=0;
  header.onmousedown = e => {
    e.preventDefault();
    sx = e.clientX; sy = e.clientY;
    document.onmousemove = e => {
      ox = sx - e.clientX; oy = sy - e.clientY;
      sx = e.clientX; sy = e.clientY;
      panel.style.top  = (panel.offsetTop  - oy) + 'px';
      panel.style.left = (panel.offsetLeft - ox) + 'px';
      panel.style.bottom = 'auto'; panel.style.right = 'auto';
    };
    document.onmouseup = () => { document.onmousemove = null; };
  };

  // Auto-scan al cargar
  setTimeout(scanPage, 2000);
  log('VForge QA activo en ' + location.pathname);
  document.getElementById('vf-qa-status').textContent = `✓ Activo — ${location.pathname}`;
})();
