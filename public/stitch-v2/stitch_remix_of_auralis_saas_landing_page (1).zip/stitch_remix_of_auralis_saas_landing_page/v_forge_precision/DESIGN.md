---
name: V Forge Precision
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1b1b1b'
  on-surface-variant: '#4c4546'
  inverse-surface: '#303030'
  inverse-on-surface: '#f1f1f1'
  outline: '#7e7576'
  outline-variant: '#cfc4c5'
  surface-tint: '#5e5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1b'
  on-primary-container: '#848484'
  inverse-primary: '#c6c6c6'
  secondary: '#5e5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e1dfdf'
  on-secondary-container: '#626262'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1b1b1b'
  on-tertiary-container: '#848484'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#e4e2e2'
  secondary-fixed-dim: '#c7c6c6'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#464747'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c6'
  on-tertiary-fixed: '#1b1b1b'
  on-tertiary-fixed-variant: '#474747'
  background: '#f9f9f9'
  on-background: '#1b1b1b'
  surface-variant: '#e2e2e2'
  surface-main: '#F7F7F5'
  surface-panel: '#F3F2EF'
  surface-card: '#FCFCFB'
  border-subtle: '#E7E7E4'
  accent-emerald: '#10B981'
  accent-indigo: '#6366F1'
  accent-purple: '#A855F7'
typography:
  display-lg:
    fontFamily: Geist
    fontSize: 84px
    fontWeight: '600'
    lineHeight: '1.05'
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.03em
  headline-md:
    fontFamily: Geist
    fontSize: 64px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.03em
  headline-sm:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  title-md:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: -0.01em
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  label-caps:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.1em
  caption:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.02em
  mono-metrics:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: '0'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 32px
  section-lg: 180px
  section-md: 140px
  section-sm: 80px
---

## Brand & Style
V Forge embodies a "Precision Tech" aesthetic, blending the clinical clarity of developer tools with the premium feel of high-end audio hardware. The brand personality is professional, innovative, and highly organized.

The design style is a sophisticated mix of **Minimalism** and **Glassmorphism**. It relies on a "Warm Tech" foundation—using off-white, bone-colored surfaces instead of pure white to reduce eye strain—complemented by vibrant, blurred atmospheric gradients that suggest the "energy" of voice and sound synthesis. The UI uses crisp, hairline borders and subtle tonal layering to establish hierarchy without heavy shadows.

## Colors
The palette is rooted in a monochromatic "Fidelity" scale. The background uses a specific warm neutral (`#F7F7F5`) to provide a canvas that feels more organic than standard digital white. 

- **Primary:** Pure black is reserved for high-contrast actions and primary headings, ensuring maximum legibility.
- **Secondary:** A medium grey (`#6B6B6B`) is used for descriptive text and secondary navigation to create a clear visual step-down from headings.
- **Accents:** Vibrant gradients (Indigo, Purple, Emerald) are used exclusively within product "hero" areas or status indicators to represent active synthesis and AI intelligence.
- **Functional:** Emerald is used for "Active/Online" states, while the background neutrals transition from a slightly darker panel color to a brighter card color to create depth.

## Typography
The system uses **Geist** exclusively to maintain a technical, developer-centric feel. 

Headlines utilize tight line-heights and negative letter-spacing to create a "locked-in" visual impact. Body text remains airy with a 1.5x line-height for long-form readability. A specialized `label-caps` style is used for section headers and overlines, featuring increased tracking (0.1em) to differentiate it from standard body copy. For data-heavy interfaces, use the heavier weights of Geist to simulate a semi-monospaced clarity for metrics and timestamps.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy centered within a 1280px container. 

- **Grid:** 12-column layout with 32px gutters.
- **Vertical Rhythm:** Large vertical gaps (140px-180px) are used to separate major narrative beats, allowing the "warm" background space to act as a premium breather.
- **Mobile Adaptation:** At the 768px breakpoint, section gaps reduce to 80px, and horizontal padding shifts from 32px to 20px. Display type scales down significantly to fit mobile widths without excessive wrapping.

## Elevation & Depth
Depth is achieved through **Tonal Layering** and **Glassmorphism** rather than traditional drop shadows.

1.  **Level 0 (Background):** Base surface color (`#F7F7F5`).
2.  **Level 1 (Panels):** Recessed or secondary areas use a slightly cooler, darker tone (`#F3F2EF`) with a hairline border.
3.  **Level 2 (Cards):** Elevated interactive cards use a brighter surface (`#FCFCFB`) with a subtle 1px border.
4.  **Level 3 (Overlays):** Glassmorphic widgets use a high degree of backdrop-blur (32px+) and semi-transparent white fills (20-40% opacity) to float above the content, often catching the "glow" of background ambient orbs.

## Shapes
The shape language transitions from highly organic to precisely engineered.
- **Large Containers:** Hero panels and major section cards use `3xl` (1.75rem or 28px) corner radii.
- **Standard UI Elements:** Default buttons and input fields use a `Full` (Pill) radius to feel friendly and approachable.
- **Internal Widgets:** Data displays and small status tags use a `lg` (0.5rem) radius for a tighter, more technical appearance.

## Components
- **Buttons:** Primary buttons are pill-shaped, solid black with white text. Secondary buttons are pill-shaped with a 1px `outline` border and no fill.
- **Chips/Tabs:** Use a pill-shaped container with a subtle background (`#F3F2EF`). Active states are indicated by a solid white fill and a small shadow.
- **Cards:** Feature a 1px border (`#E7E7E4`). Hover states should trigger a very soft, diffused shadow or a slight border color shift to the primary color.
- **Glass Widgets:** Used for AI-driven data. Must include a `border-white/40` and `backdrop-blur-3xl`.
- **Status Indicators:** Small 8px circles with a pulse animation for "Live" or "Active" states, primarily in Emerald.
- **Icons:** Use Material Symbols Outlined, maintaining a consistent stroke weight (400) and optical size (24px).