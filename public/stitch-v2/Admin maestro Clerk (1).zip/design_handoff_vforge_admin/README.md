# Handoff: vForge Admin — Panel Multitenant

## Overview
Panel de administración multitenant para la plataforma **vForge** (vforge.site): una "super integradora" donde cada tenant (negocio cliente, ej. el demo "Tacos El Gallo") administra su app generada por IA sin tocar GitHub/Vercel directamente. 26 pantallas funcionales con jerarquía **Developer → Tenant → Workspace → Scope → Site**.

## About the Design Files
Los archivos de este paquete son **referencias de diseño creadas en HTML** — prototipos que muestran el look y el comportamiento esperado, NO código de producción para copiar directo. La tarea es **recrear estos diseños en el stack objetivo del proyecto**: Next.js (App Router) + Neon Postgres + Clerk (auth/orgs) + Resend + Stripe/MercadoPago + Google Maps + Vercel, usando sus patrones establecidos. El archivo principal (`vForge Admin.dc.html`) se abre directo en el navegador para explorar todas las pantallas e interacciones.

## Fidelity
**High-fidelity (hifi)**: colores, tipografía, espaciado, radios e interacciones son finales. Recrear pixel-perfect. Toda la lógica de datos es simulada en memoria (estado del componente `Component` en el `<script>` del archivo) — sirve como spec de shape de datos y transiciones de estado.

## Identidad visual (Forge — obligatoria)
- **Monocromo estricto**: Negro `#000000`, Blanco `#FFFFFF`, Gris `#6B7280`. PROHIBIDO color en el chrome (nada de morados, azules, verdes brand). Estados semánticos también en grises: ok `#374151`, warn `#6B7280`, err `#000000` (modo oscuro: `#D1D5DB` / `#9CA3AF` / `#FFFFFF`).
- **Tipografía**: Inter (o Geist) pesos **300/400/500 únicamente — nunca bold (600+)**. Logo "Forge" en peso 300 con letter-spacing 0.24em. Código/IDs en JetBrains Mono.
- **Botones**: primario = fondo `var(--accent)` (negro en claro, blanco en oscuro), texto `var(--btn-fg)` (contraste automático), radio **10px**, **sin sombras**. Secundario = borde `var(--border)`, fondo transparente.
- **Tokens CSS** (en `:root` / `[data-theme="dark"]` del archivo): `--bg #F9FAFC/#0C0D13`, `--surface #FFFFFF/#141518`, `--border #E2E5ED/#2A2C33`, `--text #1F2937/#E5E7EB`, `--text2 #6B7280/#9CA3AF`, `--accent`, `--btn-fg`, `--accent-soft`, `--hover`, `--shadow:none`, `--shadow-el` (solo modales).
- **Radios**: 10px global. **Sombras**: ninguna en tarjetas (solo borde 1px); `--shadow-el` sutil para modales/dropdowns.
- **Iconografía**: SVG stroke inline delgado (stroke-width 1.8–2), monocromático, estilo GitHub. PROHIBIDO Lucide como librería y rellenos complejos.
- Logo: triángulo invertido negro (`M0 0h16L8 14z`) + wordmark espaciado.

## Estructura (shell)
- **Sidebar 236px**: logo Forge + badge DEV → label TENANT + switcher de tenant (dropdown) → selects de jerarquía WORKSPACE (Producción/Staging/Desarrollo), SCOPE (Global/por sucursal), SITE (dominio/app/kiosko) → botón Buscar ⌘K → nav agrupada en OPERACIÓN / NEGOCIO / PERSONAS / PLATAFORMA → footer con avatar de usuario, rol "Developer" y toggle claro/oscuro.
- **Header 56px**: título + subtítulo de pantalla, breadcrumb mono `tenant / workspace / scope / site`, indicador "Sistema estable", botón ayuda "?" con popover contextual por pantalla.
- **⌘K command palette**: grupos "IR A" (todas las pantallas) y "ACCIONES", filtro por texto, Esc cierra.
- **Toast** inferior derecha para confirmaciones (2.4 s).
- Tema claro/oscuro con `data-theme` en el root; el acento se invierte (negro↔blanco).

## Screens (26)
Grupo OPERACIÓN:
1. **Salud** (home): score 0–100 en anillo SVG animado, 4 KPIs (uptime, errores 24h, latencia p95, pagos fallidos), diagnóstico de IA en texto, botón "Pedir a la IA que lo arregle" (estado fixing→fixed: resuelve 2 de 3 alertas, actualiza KPIs/score 87→94), lista de alertas priorizadas con severidad.
2. **Deploys**: pestañas Pipeline / Salud de conexión. Pipeline: 5 pasos (Prompt aprobado → Commit a GitHub → Build en Vercel → Preview → Producción) con estados done/current/pending, URL de preview, botones "Promover a producción" (avanza pipeline + inserta deploy en historial) y "Descartar cambio"; historial de deploys (id, entorno, cambio, commit, autor, estado). Salud: tarjetas GitHub (instalación App scope `repo`, latencia, rate limit, webhooks) y Vercel (token scope `project`, entornos, minutos build) con "Probar conexión" y links "Abrir en GitHub/Vercel ↗"; stream de eventos webhook con timestamps y resultados.
3. **Centro de Comando C4**: 4 sistemas con estado, mapa con repartidores en vivo (pines pulsantes) + sucursales, pedidos en vivo con ETA, tarjeta de incidente activo que enlaza a Salud.
4. **Developers**: hilo de chat con el equipo (enviar funcional), tickets con SLA y semáforo, tarjeta de SLA del plan.
5. **Prompts**: input de cambio en lenguaje natural, cola con estados Pendiente/Aprobado/Rechazado, preview del cambio, botones Aprobar/Rechazar funcionales, badge de pendientes en la nav.
6. **Contenido**: lista de secciones (Hero, Menú, Promos, FAQ, Footer), editor de campos con preview vivo del sitio del tenant, publicar/despublicar, historial de versiones con restaurar.

Grupo NEGOCIO:
7. **Precios y Catálogo**: tabla de productos con edición inline de precio (click en el precio → input + ✓/✕), selector MXN/USD (convierte a tipo de cambio 17.1), reglas de precio (activa/programada).
8. **Sucursales**: tarjetas por sucursal con KPIs del día, mapa con pines, tabla comparativa mensual.
9. **Gastos y Pasivos**: 4 KPIs financieros, registro de gastos funcional (formulario inline → inserta fila y actualiza KPI), pasivos con barra de avance.
10. **Facturación**: plan Forge PRO $1,499 MXN/mes, método de pago, historial de facturas CFDI.
11. **Analytics**: 4 KPIs, gráfica de ventas 30 días (SVG polyline), ventas por canal (barras), top productos.

Grupo PERSONAS:
12. **Clientes (CRM)**: búsqueda en vivo, tabla (pedidos/LTV/última visita), panel de perfil amplio: tags, LTV, contacto, dirección, pago guardado, toggle consentimiento marketing, últimos pedidos, notas internas editables.
13. **Mensajería**: bandeja unificada (WhatsApp/Facebook/chat web) con no-leídos, hilo con respuesta funcional, acciones "Ver perfil CRM"/"Crear ticket".
14. **Equipo y Roles**: miembros con selector de rol (Propietario/Admin/Developer/Marketing/Solo lectura) que actualiza chips de permisos, invitación pendiente.
15. **Trabajadores**: formulario de alta (nombre/puesto/sucursal/rol/salario → inserta fila, "invita vía Clerk+Resend"), tabla con sucursal y rol editables por fila.
16. **Redes Sociales**: cuentas IG/FB/TikTok/X/YouTube con handle editable y toggle de conexión, publicaciones programadas.

Grupo PLATAFORMA:
17. **White-Label**: logo (file upload → preview), sliders texto 12–20px / titulares 20–40px / radio 0–18px / espaciado 8–28px, 5 presets de paleta neutros (Tinta/Carbón/Grafito/Acero/Piedra), modo claro/oscuro, preview vivo de la app del tenant, "Aplicar a la app" con modal de confirmación.
18. **Notificaciones**: toggles por canal (push/email/SMS/WhatsApp), plantillas con preview de notificación, "Enviar prueba", panel **VAPID** (clave pública copiable, privada revelable, regenerar par).
19. **Integraciones**: Stripe, MercadoPago, Composio, Clerk, Twilio, Google Analytics — toggle + estado de sincronización + error de credencial enlazado a Bóveda.
20. **Base de Datos**: tarjetas de conexión Neon/Clerk/Resend/Google Maps/Stripe/MercadoPago con stats y "Probar" (ping), explorador SQL con preview de filas.
21. **Bóveda**: keys (STRIPE_SECRET_KEY, MP_ACCESS_TOKEN, CLERK_SECRET_KEY, NEON_DATABASE_URL) con revelar/copiar/**rotar** (genera nueva, la anterior expira en 24 h), tarjeta de repositorio, credenciales de integraciones.
22. **Legal y Garantías**: pestañas Términos/Privacidad/Garantía con textarea editable, versionado (vigente + históricas), contador de aceptaciones, exportar CSV.
23. **Módulos**: catálogo de 42 capacidades activables por toggle (reservas, lealtad, POS, KDS, CFDI, NPS, chatbot IA, RFM, nómina, SEO local, etc.) con categoría.
24. **Audit Log**: registro inmutable filtrable por tipo/usuario/fecha, con IP y timestamp mono.
25. **Mi Perfil**: datos editables (nombre/tel/RFC), email Clerk bloqueado, idioma/TZ, 2FA toggle, sesiones activas con cerrar remoto, notificaciones personales.
26. (Shell) Switcher multi-tenant con 3 tenants demo.

## Interactions & Behavior
- Toda mutación muestra toast de confirmación.
- Hovers: `--hover` en filas/botones; focus: outline 2px gris.
- Animaciones: `pulse` (dots en vivo), `fadeUp` 0.12–0.18s (dropdowns/modales/toast). Sutiles: fade/opacity, nada rebota.
- ⌘K / Ctrl+K abre palette; Esc cierra overlays.
- El estado `fixed` de Salud se refleja también en C4 y Base de Datos (MercadoPago pasa a OK).

## State Management (mapa a producción)
- Tenant/workspace/scope/site → org + metadata de Clerk / tabla tenants en Neon; el breadcrumb refleja el contexto activo de la sesión.
- Prompts/aprobaciones → tabla `change_requests` con estados; aprobar dispara pipeline GitHub→Vercel (commit + preview deploy), promover = promote to production vía API de Vercel.
- Bóveda → secrets cifrados (no en cliente); rotación con periodo de gracia 24 h; todo acceso escribe en audit log.
- Push → suscripciones Web Push con VAPID; regenerar invalida suscripciones.
- CRM/trabajadores/gastos → tablas en Neon con RLS por tenant.

## Assets
Sin assets binarios: logos e iconos son SVG inline; el logo del white-label lo sube el usuario. Fuentes vía Google Fonts (Inter 300/400/500, JetBrains Mono 400/500).

## Files
- `vForge Admin.dc.html` — diseño principal (26 pantallas, identidad Forge). LA referencia a implementar.
- `v-adm Admin.dc.html` — versión anterior con identidad Clerk (histórico, solo referencia).
